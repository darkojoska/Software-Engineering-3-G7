﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace KWIC_Index_System
{
    class CircularShift
    {
        public List<string> ShiftLines(List<string> lines)
        {
            List<string> changed = new List<string>();

            foreach (var item in lines)
            {
                  String[] elements = Regex.Split(item, " ");
                  var elementsList = new List<string>();
                  foreach (var element in elements){
                      string temp = element;
                      elementsList = elements.ToList();
                      elementsList.Remove(element);
                      elementsList.Add(temp);
                      var combined = string.Join(" ", elementsList);
                      changed.Add(combined);
                      elements = elementsList.ToArray();
               }
            }    
            return changed;
        }
    }
}
