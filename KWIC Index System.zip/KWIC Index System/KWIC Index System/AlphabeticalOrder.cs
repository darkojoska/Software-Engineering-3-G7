﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KWIC_Index_System
{
    class AlphabeticalOrder
    {
        public List<string> Sort(List<string> lines)
        {
            List<string> sorted = lines;
            sorted.Sort();
            return sorted;
        }
    }
}
