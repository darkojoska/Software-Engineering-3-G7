﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KWIC_Index_System
{
    class ReadFile
    {
        private string input;
        private string output;

        public ReadFile() {
            SetInput();
            SetOutput();
        }

        public void SetInput()
        {
            Console.WriteLine("Enter input file name (input or input.txt): ");
            this.input = Console.ReadLine();
        }

        public string GetInput()
        {
            return this.input;
        }

        public void SetOutput()
        {
            Console.WriteLine("Enter output file name: ");
            this.output = Console.ReadLine();
        }

        public string GetOutput()
        {
            return this.output;
        }

        public List<string> Read()
        {
            List<string> lines = new List<string>();
            
            if (GetInput().Contains(".txt"))
            {
              lines = System.IO.File.ReadLines(GetInput()).ToList();
            }
            else if (!GetInput().Contains(".txt") && GetInput().Contains("input"))
            {
                lines = System.IO.File.ReadLines(GetInput() + ".txt").ToList();
            }
            else if (!GetInput().Contains(".txt") && !GetInput().Contains("input"))
            {
                Console.WriteLine("Invalid input for input file. Try again...");
                Read();
            }
            return lines;
        }
    }
}
