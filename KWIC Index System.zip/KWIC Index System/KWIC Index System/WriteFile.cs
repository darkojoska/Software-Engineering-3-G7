﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KWIC_Index_System
{
    class WriteFile
    {
        public List<string> Write(List<string> liness, string name)
        {
            List<string> lines = liness;
            string path = @"..\..\" + name + ".txt";
            using (System.IO.StreamWriter file =
                new System.IO.StreamWriter(path))
            {
                foreach (string line in lines)
                {
                        file.WriteLine(line);
                }
            }
            Console.Out.WriteLine("Output file '" + name + ".txt' successfully created in folder: 'KWIC Index System'");
            Console.Out.Write("Press any key to exit...");
            Console.ReadKey(true);
            return null;
        }
    }
}
