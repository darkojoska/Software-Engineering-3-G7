﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace KWIC_Index_System
{
    class Store
    {
        public List<string> Storing(List<string> lines)
        {
            List<string> back = lines;
            return back;

        }
    }
}
