﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace KWIC_Index_System
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadFile rf = new ReadFile();
            Store s = new Store();
            CircularShift cs = new CircularShift();
            AlphabeticalOrder ao = new AlphabeticalOrder();
            WriteFile wF = new WriteFile();

            wF.Write(ao.Sort(cs.ShiftLines(s.Storing(rf.Read()))), rf.GetOutput());
        }
    }
}